angular.module('project').service('ProjectService', function() {

	var storage;
	var index = 0;
	var self = this;

	this.init = function() {
		storage = new js_cols.HashMap();
		self.save({ name: "test1", site: "http://test1", description: "description 1"});
		self.save({ name: "test2", site: "http://test2", description: "description 2"});
	};

	this.save = function(project) {
		if (!project._id) {
			index++;
			project._id = index.toString();
		}
		storage.insert(project._id, project);
		return self.clone(project);
	};

	this.get = function(id) {
		if (!storage) {
			self.init();
		}
		return self.clone(storage.get(id));
	};

	this.remove = function(project) {
		return storage.remove(project._id);
	};
	
	this.clone = function(project) {
		var clone = {};
		clone._id = project._id;
		clone.name = project.name;
		clone.site = project.site;
		clone.description = project.description;
		return clone;
	};	

	this.contains = function(id) {
		return storage.contains(id);
	};

	this.query = function() {
		if (!storage) {
			self.init();
		}
		return storage.getValues();
	};

});
