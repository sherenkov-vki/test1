angular.module('project', []).config(function($routeProvider) {
	$routeProvider.when('/', {
		controller : 'ListController',
		templateUrl : 'project/view/list.html'
	}).when('/edit/:projectId', {
		controller : 'EditController',
		templateUrl : 'project/view/detail.html'
	}).when('/new', {
		controller : 'CreateController',
		templateUrl : 'project/view/detail.html'
	}).otherwise({
		redirectTo : '/'
	});
});

