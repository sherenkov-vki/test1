angular.module('project').controller('ListController', function ($scope, ProjectService) {

	$scope.projects = ProjectService.query();
	
});
