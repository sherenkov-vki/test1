angular.module('project').controller('EditController', function ($scope, $location, $routeParams, ProjectService) {

	var self = this;

	self.original = ProjectService.get($routeParams.projectId);
	
	$scope.project = ProjectService.clone(self.original);

	$scope.isClean = function() {
		return angular.equals(self.original, $scope.project);
	}

	$scope.destroy = function() {
		ProjectService.remove($scope.project);
		$location.path('/list');
	};

	$scope.save = function() {
		ProjectService.save($scope.project);
		$location.path('/');
	};
	
});
