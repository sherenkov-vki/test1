angular.module('project').controller('CreateController', function ($scope, $location, ProjectService) {

	$scope.save = function() {
		ProjectService.save($scope.project);
		$location.path('/list');
	}
	
});
